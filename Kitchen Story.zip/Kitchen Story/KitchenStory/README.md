# KitchenStory
Simplilearn Phase-2 final project<br><br>

# External dependency
This app depends on a custom Json Server for all the users and items data which can be cloned from the below link
https://github.com/rahul-sk/CustomJsonServer.git <br>
Once cloned, run <strong>npm start</strong> to start the json server.
# Development server
Run <strong>ng serve -o</strong> for a dev server. The app will be automatically rendered in the browser . The app will automatically reload if you change any of the source files.
<br><br>
# Code scaffolding
Run ng generate component component-name to generate a new component. You can also use ng generate directive|pipe|service|class|guard|interface|enum|module.

# Screenshots
![Capturefood](https://user-images.githubusercontent.com/37139616/137162515-b779ffc1-8bd1-44f3-a283-6b5faf9bdffe.PNG)
<br><br>
![f4](https://user-images.githubusercontent.com/37139616/137163682-0d94d59f-5102-448f-b2d1-f427dfdb449f.PNG)
<br><br>
![f5](https://user-images.githubusercontent.com/37139616/137163689-6a1cd98a-43e5-4d4f-a1cc-619eb09a5c28.PNG)
<br><br>
![f6](https://user-images.githubusercontent.com/37139616/137163701-5855bde6-5b15-4b40-af1d-a201e237f8fb.PNG)
<br><br>
![f7](https://user-images.githubusercontent.com/37139616/137163705-56fe5e06-eb31-43be-98c2-77656eeaa428.PNG)
<br><br>
![f2](https://user-images.githubusercontent.com/37139616/137163711-1e6a33ac-a061-45be-8f42-58c4f4402f2a.PNG)
<br><br>
![f3](https://user-images.githubusercontent.com/37139616/137163724-663b174c-8875-4513-95b0-5e4c8bae7070.PNG)

